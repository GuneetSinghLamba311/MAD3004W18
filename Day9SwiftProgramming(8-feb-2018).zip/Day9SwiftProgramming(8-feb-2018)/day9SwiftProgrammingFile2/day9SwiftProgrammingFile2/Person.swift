//
//  Person.swift
//  day9SwiftProgrammingFile2
//
//  Created by MacStudent on 2018-02-08.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class Person {
    let name:String
    var Age:Int
   
    init?(name:String,age:Int) { // Initialinzer
        if name == " " {
            return nil
        }
        else {
            self.name = name
            self.Age = age
        }
    }
    
    
    func isValid(Age:Int) -> Bool // Function to check index out of bound
    {
        return Age >= 18
    }
    
    subscript(CheckAge:Int)->Int // Subscript.
    {
        get {
            assert(isValid(Age: CheckAge),"Index Out of range")
            return CheckAge
        }
        set{
            assert(isValid(Age: CheckAge),"Index Out of range")
           Age = newValue
        }
    }
    
    
}
