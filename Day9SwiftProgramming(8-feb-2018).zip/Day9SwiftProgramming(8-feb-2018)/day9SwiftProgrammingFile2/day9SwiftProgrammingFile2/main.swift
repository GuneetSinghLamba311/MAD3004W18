//
//  main.swift
//  day9SwiftProgrammingFile2
//
//  Created by MacStudent on 2018-02-08.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

struct TimesTable {
    
    // subscript to be applied on multiplier
    let multiplier: Int
    
    
    subscript(index:Int) -> Int {
        
        
        return multiplier * index
    }
}
let threeTimesTable = TimesTable(multiplier: 3)
print("Six Times three is \(threeTimesTable[6])")

struct Matrix {
    let rows:Int, columns: Int
    var grid:[Double]
   
    init(rows: Int, columns: Int){ // 1. initializer
        self.rows = rows
        self.columns = columns
        grid = Array(repeating:0.0,count: rows * columns)
    }
    func indexIsValid(row:Int,column:Int) -> Bool { // 2. Function
        return row >= 0 && row < rows && column >= 0 && column < columns
    }

    subscript(row:Int,column:Int) -> Double { // 3/ Subscript
        get {
            assert(indexIsValid(row: row, column: column),"Index out of range")
            return grid[(row * columns) + column]
        }
    
        set {
            assert(indexIsValid(row: row, column: column),"Index out  of range")
            grid[(row * columns) + column] = newValue
        }
        
    }
}

var matrix = Matrix(rows: 2, columns: 2) // for initializer
print("\(matrix.grid)")
matrix[0,1] = 1.5 // passing value to subscript
matrix[1,0] = 3.2 // passing value to subscript
print("\(matrix.grid)")


// Class Activity to perform Subscript on classes.
var Ojb2 = Person(name: "Guneet", age: 23)
print("Age\(Ojb2![23])")
print("\(Ojb2?.Age)")
print("\(Ojb2?.name)")





