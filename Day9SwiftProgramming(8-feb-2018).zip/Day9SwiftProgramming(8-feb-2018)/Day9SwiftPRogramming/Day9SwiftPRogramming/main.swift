//
//  main.swift
//  Day9SwiftPRogramming
//
//  Created by MacStudent on 2018-02-08.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation



var objManu = Manufacturer(name: "audi")
print("\(objManu.name)")
var objManu2 = Manufacturer(name: " ")
var vehObj2 = Vehicle(name: "BIKE", noOfWheels: 2)
print("\(vehObj2)")
var PrefObj = Preference(name: "Bike", noOfWheels: 2)
print(PrefObj.description)


/// Class Activity.




