//
//  Person.swift
//  Day8SwiftProgramming
//
//  Created by MacStudent on 2018-02-08.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation


// Class Activity.
class Person {
    let Firstname:String
    let lastname:String
    let address:String
    init?(Firstname:String,lastname:String,address:String) {
        
        self.Firstname = Firstname
        self.lastname = lastname
        self.address = address
        }
    
}
