//
//  main.swift
//  Day8SwiftProgramming
//
//  Created by MacStudent on 2018-02-08.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation


var Laptop = Product(name: "Laptop")

if let machine = Laptop {

    print("Product name is \(machine.name)")
}

let anonymousMachine = Product(name: " ")

if anonymousMachine == nil {
    
    print("The anonymous machine could not be initialized")
}
/*
if let  cartItem_Object =  CartItem(name: "Milk", quantity: 0)
{
    print("Cart Contains \(cartItem_Object.quantity) \(cartItem_Object.name)")
    
}
else {
    print("Unable to initialize cart item")
}
*/

// Class Activity.
let lic = License(Firstname: "Will", lastname: "Smith", address: "MAxStreet", age: 12, location: "Toronto")
if lic == nil {
        print("Object Cannot be created")
    }
    else {
        print("Eligible for licnese")
    print(lic?.Age)
    print(lic?.Firstname)
    print(lic?.lastname)
    print(lic?.address)
    print(lic?.Location)
    }









