//
//  License.swift
//  Day8SwiftProgramming
//
//  Created by MacStudent on 2018-02-08.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

// Class Activity
class License: Person  {
    
    var Age:Int
    var Location:String
    
    init?(Firstname:String, lastname:String, address:String,age:Int,location:String) {
        
    if age < 16 {
            return nil
            }
        else
    {       self.Age = age
            self.Location = location
        }
        super.init(Firstname:Firstname, lastname: lastname, address: address)
}
}
