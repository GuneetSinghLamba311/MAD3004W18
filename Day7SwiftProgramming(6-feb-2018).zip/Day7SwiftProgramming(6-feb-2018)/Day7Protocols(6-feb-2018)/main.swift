//
//  main.swift
//  Day7Protocols
//
//  Created by Jigisha Patel on 2018-02-06.
//  Copyright © 2018 JK. All rights reserved.
//

import Foundation

var obj1 = TestA()
obj1.n1 = 20
//obj1.display()
//obj1.displayValue()

var obj2 = TestB()
obj2.n1 = 30
obj2.n2 = 40
//obj2.display()
//obj2.displayValue()

var obj3 = obj2 as TestA
//obj3.display()
//obj3.displayValue()

var objArith = Arithmetic(n1: 20, n2: 30)
//objArith.calculate()

var objOperation = Operation(n1: 30, n2: 40, oper: "*")
//objOperation.calculate()

//using double extension
let oneInch = 25.4.mm
print("One inch is \(oneInch) meters")
let threeFeet = 3.ft
print("Three feet is \(threeFeet) meters")

let aMarathon = 42.km + 195.m
print("A marathon is \(aMarathon) meters long")

//using String extension
var s = "Hello"
print(s.length)
print(s.vowels)
print(s.consonants)
print(s.contains(s: "el"))


// Class Activity for Int extension

var number = 5
print(number.prime)
print(number.contains(n: number))







