//
//  TestA.swift
//  Day7Protocols
//
//  Created by Jigisha Patel on 2018-02-06.
//  Copyright © 2018 JK. All rights reserved.
//

import Foundation

class TestA: IDisplay, IDisplayValue{
    var n1: Int = 20
    
    func displayValue() {
        print("Value of n1 : \(self.n1)")
    }
    
    func display() {
        print("Inside Class TestA")
    }
    
}
