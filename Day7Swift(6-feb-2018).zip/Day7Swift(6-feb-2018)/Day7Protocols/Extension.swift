//
//  Extension.swift
//  Day7Protocols
//
//  Created by Jigisha Patel on 2018-02-06.
//  Copyright © 2018 JK. All rights reserved.
//

//: Playground - noun: a place where people can play

import Foundation
//-------------------------------------------------------------------
extension Double {
    var km: Double { return self * 1_000.0 }
    var m: Double { return self }
    var cm: Double { return self / 100.0 }
    var mm: Double { return self / 1_000.0 }
    var ft: Double { return self / 3.28084 }
}


//------- String Extension ------------
extension String
{
    var length: Int {
        get {
            return self.count
        }
    }
    
    func contains(s: String) -> Bool
    {
        return true
    }
    
    var vowels: [String]
    {
        get
        {
            return ["a", "e", "i", "o", "u"]
        }
    }
    
    var consonants: [String]
    {
        get
        {
            return ["b", "c", "d", "f", "g", "h", "j", "k", "l", "m", "n", "p", "q", "r", "s", "t", "v", "w", "x", "z"]
        }
    }
}

//task for the day:
// create an extension to Int type to find out that the number if prime or not

///// ----- Class Activity wiht Int extension.-------
extension Int {
    
    func  contains(n:Int) -> Bool {
        
        return true
    }
    
    
    var prime: [Int] {
        
        get {
            return [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97]
        }
    }
}




