//
//  Parttime.swift
//  Day11SwiftProgramming_AccessControl(12-02-2018)
//
//  Created by Guneet Singh Lamba on 12/02/18.
//  Copyright © 2018 Guneet Singh Lamba. All rights reserved.
//

import Foundation

class PartTime { // Studnet and full time cannot be extended as file private.
    
    
    var sname: String?
   
  func setStudentName(sname: String)
    {
        self.sname = sname
    }

}

internal class ExtendedPartime: PartTime {

    override internal func setStudentName(sname: String) {
        super.setStudentName(sname: sname)
    }
}



class T: ExtendedPartime {
    
    override init() {
        super.init()
        print("Display T")
    }
    
}

var t1 = T()











