//
//  Student.swift
//  Day11SwiftProgramming_AccessControl(12-02-2018)
//
//  Created by Guneet Singh Lamba on 12/02/18.
//  Copyright © 2018 Guneet Singh Lamba. All rights reserved.
//

import Foundation


// File private class student.
fileprivate class Student
{
   private var sname:String?
    
    
    
    init() {
        self.sname = "Student Name"
    }
    
    fileprivate func setStudentName(sname:String)
    {
        self.sname = sname
    }
    func getStudentName() -> String {
        
        return self.sname!
    }
    
    
     private func display() {
    
        print("I am private method of student class")
}
    
   private func display(message:String){
        
        print("Hello",message)
        
}
    }


// Fulltime class is of private typr because student is of private type.
private class FullTime: Student {
    
    
    var subject: String?
    
    override init() {
        
        self.subject = "Fulltime Subject"
        
}
    
    private func setSubject(subject: String)
    {
        self.subject = subject
    }
    
    fileprivate func display() {
        print("Method of fulltime class")
        print("I am method of Fulltime Class")
      //  super.display(message: "File Private")
    
}

}






