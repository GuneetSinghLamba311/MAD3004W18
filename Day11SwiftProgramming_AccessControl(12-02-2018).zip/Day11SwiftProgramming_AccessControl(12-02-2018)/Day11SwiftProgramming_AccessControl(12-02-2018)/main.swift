//
//  main.swift
//  Day11SwiftProgramming_AccessControl(12-02-2018)
//
//  Created by Guneet Singh Lamba on 12/02/18.
//  Copyright © 2018 Guneet Singh Lamba. All rights reserved.
//

import Foundation


//var objStud = Student()

//objStud.display()
//objStud.display(message: "JK")

var partTimeObj = PartTime()
partTimeObj.setStudentName(sname: "Guneet")
