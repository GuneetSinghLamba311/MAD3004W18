//
//  main.swift
//  Day13SwiftProgramming(14-02-2018)
//
//  Created by Guneet Singh Lamba on 14/02/18.
//  Copyright © 2018 Guneet Singh Lamba. All rights reserved.
//

import Foundation
import Cocoa


var e1 = Employee()
print(Employee.getNoOfObject())
e1.greet(name: "Guneet")
var e2 = Employee()
print(Employee.getNoOfObject())
var p1 = PartTime()
p1.greet(name: "p1")
//p1.getNoOfObject() // cannot be accesed through sub class object. //Error

e1 = p1
e1.greet(name: "NAME")

var r1: Employee
r1 =  Employee()
r1.greet(name: "Employee")

r1 = PartTime()
r1.greet(name: "Parttime")

// Reference
p1 = e1 as! PartTime
p1.greet(name: "Andy")

print(" ")

let tutorial = Tutorial(title: "Swift", author: "cosmin", editor: "simon g", type: "Swift", publishDate: Date())
let encoder = JSONEncoder()
let EncodeData = try encoder.encode(tutorial)
let JsonString = String(data: EncodeData, encoding: .utf8)
print(JsonString ?? "")
let Decoder = JSONDecoder()
let article = try Decoder.decode(Tutorial.self,from: EncodeData)
let info =  "\(article.title) \(article.author)\(article.editor) \(article.type) \(article.publishDate)"
print(" Decoded Data: \(info)")

func matches(for regex: String, in text: String) -> [String] {
    
    
    do {
        let regex = try NSRegularExpression(pattern: regex)
        let result = regex.matches(in: text, range: NSRange(text.startIndex...,
                                                             in: text))
        
        return result.map {
            String(text[Range($0.range, in: text)!])
        }
    } catch let error {
        print("invalid regex : \(error.localizedDescription)")
            return []
    }
}
    
    
    /////////------------///////////////////
    let string = "🇩🇪€4€9--45;;9"
    let matched = matches(for: "€[0-9]€", in: string)
    print(matched)
    let pat = "\\b([a-z])\\.([a-z]{2,})@([a-z]+)\\.ac\\.uk\\b"
    let testStr = "x.wu@strath.ac.uk, ak123@hotmail.com     e1s59@oxford.ac.uk, ee123@cooleng.co.uk, a.khan@surrey.ac.uk"
    
    let emailList = matches(for: pat, in: testStr)
    print(emailList)
    
    // --------Email Validation Function--------
    func isValidEmail(testStr:String) -> Bool {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        
        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailTest.evaluate(with: testStr)
    }

    
    if(isValidEmail(testStr: "test123@gmail.com"))
    {
        print("Valid Email Address")
    }
    else
    {
        print("Invalid Email Address")
    }
    
    
    if(isValidEmail(testStr: "test123gmail.com"))
    {
        print("Valid Email Address")
    }
    else
    {
        print("Invalid Email Address")
    }

    
    
    
    












