//
//  Tutorial.swift
//  Day13SwiftProgramming(14-02-2018)
//
//  Created by Guneet Singh Lamba on 14/02/18.
//  Copyright © 2018 Guneet Singh Lamba. All rights reserved.
//

import Foundation

class Tutorial: Codable {
    
    let title:String
    let author: String
    let editor:String
    let type:String
    let publishDate:Date
    
    init(title:String,author:String,editor:String,type:String,publishDate:Date)
    {
       self.title = title
        self.author = author
        self.editor = editor
        self.type = type
        self.publishDate = publishDate
        
        }
}
    
    
    

