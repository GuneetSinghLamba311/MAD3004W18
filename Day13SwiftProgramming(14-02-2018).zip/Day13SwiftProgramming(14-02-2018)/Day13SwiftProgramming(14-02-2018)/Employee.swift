//
//  Employee.swift
//  Day13SwiftProgramming(14-02-2018)
//
//  Created by Guneet Singh Lamba on 14/02/18.
//  Copyright © 2018 Guneet Singh Lamba. All rights reserved.
//

import Foundation


class Employee {
    
    let MIN_PAY = 11.60
    var a:String?
    static var noOfObject = 0
    
    init() {
        Employee.noOfObject += 1
    }
    // Use of static keyword.
    static func getNoOfObject()-> Int {
            // a = "Test" // Not allowed.
        return noOfObject
        }
    func greet(name: String) {
        
        print("Employee :: Want to join the team? \(name)")
    }
    deinit {
        print("Employee Deinit")
    }
    
}




















