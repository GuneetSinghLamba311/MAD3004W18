//
//  PartTime.swift
//  Day13SwiftProgramming(14-02-2018)
//
//  Created by Guneet Singh Lamba on 14/02/18.
//  Copyright © 2018 Guneet Singh Lamba. All rights reserved.
//

import Foundation


class PartTime: Employee {
    
    override func greet(name: String) {
        print("Part time :: Want to work full time? \(name)")
    }
    
    deinit {
        print("ParT time deinit")
    }
}


